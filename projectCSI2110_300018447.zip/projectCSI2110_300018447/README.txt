CSI2110 Programming Assignment 1 - Diamond Min-Max Heap
Student name: Leo Tan
Student number: 300018447
Include files: README.txt, input1.txt, input2.txt, output1.txt, output2.txt, Max_Min_Heap.java

Student comments: If my program doesn't produce the correct outputs as your answers, then please read over my code.
Some of the methods in the java file weren't used at all, and there are a lot of commented out print statements.
When you run the java file in command prompt, you will have to give an text file.
For example, "java Max_Min_Heap name_of_your_text_file.txt"